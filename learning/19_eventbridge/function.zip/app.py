import json
from datetime import datetime
import boto3

# EventBridge client
eventbridge_client = boto3.client('events')


def lambda_handler(event, context):    
    print('Starting input lambda function call')
    print(event)

    # Example event from your application
    my_application_event_example = {
        'service': 'myapp service',
        'status': 'restored'
    }

    # Structure of EventBridge Event
    eventbridge_event = {
        'Time': datetime.utcnow(),
        'Source': 'com.mycompany.myapp',
        'Detail': json.dumps(my_application_event_example),
        'DetailType': 'service_status',
        'EventBusName': 'MyCustomEventBus'
    }
    # Send event to EventBridge
    putEventSend = eventbridge_client.put_events(
        Entries=[
            eventbridge_event
        ]
    )

    print(putEventSend)

    response = {
        'statusCode': 200,
        'body': json.dumps('successfully created item!'),
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
    }
    
    return response