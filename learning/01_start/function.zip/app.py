import os
import json

def lambda_handler(event, context):
    # TODO implement
    print('Starting input lambda function call')
    print(event)
     
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!!!')
    }
